#include<iostream>

using namespace std;

void f1() {
	cout << "this is f1 " << endl;
}
