#include<iostream>

using namespace std;

void f2() {
	cout << "this is f2 " << endl;
}
